#H01_2C2230004_01.py
#program asumsi keuntungan tiap barang selalu ada

# Input harga dasar dan harga jual barang 
harga_dasar_A = int(input("Masukkan harga dasar barang A: "))
harga_jual_A = int(input("Masukkan harga jual barang A: "))
harga_dasar_B = int(input("Masukkan harga dasar barang B: "))
harga_jual_B = int(input("Masukkan harga jual barang B: "))
harga_dasar_C = int(input("Masukkan harga dasar barang C: "))
harga_jual_C = int(input("Masukkan harga jual barang C: "))

# Hitung keuntungan untuk masing-masing barang
keuntungan_A = harga_jual_A - harga_dasar_A
keuntungan_B = harga_jual_B - harga_dasar_B
keuntungan_C = harga_jual_C - harga_dasar_C

# Tentukan barang dengan keuntungan terbesar
if keuntungan_A > keuntungan_B and keuntungan_A > keuntungan_C:
    print("Barang yang harus ditawarkan adalah barang A")
elif keuntungan_B > keuntungan_A and keuntungan_B > keuntungan_C:
    print("Barang yang harus ditawarkan adalah barang B")
else:
    print("Barang yang harus ditawarkan adalah barang C")
