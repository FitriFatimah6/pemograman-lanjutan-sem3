def kelas_mahasiswa(nrp_akhir):
  nrp_akhir = int(nrp_akhir)

  # menentukan kelas berdasarkan rentang NRP
  if 1 <= nrp_akhir <= 100:
    return "K1" if nrp_akhir % 2 != 0 else "K2"
  elif 101 <= nrp_akhir <= 200:
    return "K3" if nrp_akhir % 2 != 0 else "K4"
  elif 201 <= nrp_akhir <= 300:
    return "K5" if nrp_akhir % 2 != 0 else "K6"
  elif nrp_akhir > 300:
    return "K7" if nrp_akhir % 2 != 0 else "K8"
  else:
    return "NRP Tidak Valid"
  
# input 3 digit terakhir NRP mahasiswa
nrp = input("Masukkan 3 digit terakhir NRP: ")
kelas = kelas_mahasiswa(nrp)

# menampilkan hasil
print(f"Mahasiswa dengan NRP {nrp} berada di kelas{kelas}.")